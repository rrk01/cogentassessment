package com.cogent.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cogent.boot.entity.Plans;
import com.cogent.boot.repo.PlansRepo;

@RestController
public class PlansController {

	@Autowired
	PlansRepo plansRepo;

	@PostMapping("/addplans")
	Plans newPlans(@RequestBody Plans plans) {
		return plansRepo.save(plans); // SQL INSERT INTO DB
	}

	@GetMapping("/getplans") // End Point
	List<Plans> getAllPlanss() {
		return plansRepo.findAll();
	}
	
	@DeleteMapping("/deleteplans/{id}")

    public void deleteById(@PathVariable("id") int id) {
        plansRepo.deleteById(id);
    }
}
